package com.example.animedash;

public class Anime {
    String name, genre, description, yearly_quarter;
    int animeid, year, episodes, seasons;

    public Anime(String name, String genre, String description, String yearly_quarter, int year, int episodes, int seasons){

        this.name = name;
        this.genre = genre;
        this.description = description;
        this.year = year;
        this.episodes = episodes;
        this.seasons = seasons;
        this. yearly_quarter = yearly_quarter;
    }


    public int getYear() { return year; }
    public String getName() { return name; }
    public String getGenre() { return genre; }
    public int getEpisode() { return episodes; }
    public int getSeasons() { return seasons; }
    public String getDescription() { return description; }
    public String getYearly_quarter() { return yearly_quarter; }


}
