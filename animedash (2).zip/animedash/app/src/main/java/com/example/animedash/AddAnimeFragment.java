package com.example.animedash;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import androidx.fragment.app.Fragment;






public class AddAnimeFragment extends Fragment {
    String URL = "https://anime-dashapi.azure-api.net/v1/api/Anime/";
    private RequestQueue mQueue;
    private Button submit;
    private EditText name, genre, description, year, episodes, seasons, yearly_quarter;

    public AddAnimeFragment() {}

    @Override
    public void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View v = inflater.inflate(R.layout.fragment_add_anime, container, false);
        name = (EditText) v.findViewById(R.id.name);
        genre = (EditText) v.findViewById(R.id.genre);
        description = (EditText) v.findViewById(R.id.description);
        year = (EditText) v.findViewById(R.id.year);
        episodes = (EditText) v.findViewById(R.id.episodes);
        seasons = (EditText) v.findViewById(R.id.seasons);
        yearly_quarter = (EditText) v.findViewById(R.id.yearly_quarter);
        submit = v.findViewById(R.id.submit);
        submit();
        return v;
    }

    public void submit(){
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Anime a = new Anime(name.getText().toString(),
                        genre.getText().toString(),
                        description.getText().toString(),
                        yearly_quarter.getText().toString(),
                        Integer.parseInt(year.getText().toString()),
                        Integer.parseInt(episodes.getText().toString()),
                        Integer.parseInt(seasons.getText().toString())
                       );

                post(a);
            }
        });
    }

    public void post(Anime a){
        JSONObject jsonObject = getParams(a);
        mQueue = Volley.newRequestQueue(getActivity().getApplicationContext());
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL, jsonObject,
                new Response.Listener<JSONObject>(){
            @Override
                    public void onResponse(JSONObject response) {

            }
        }, new Response.ErrorListener(){

            @Override
            public void onErrorResponse(VolleyError error){
                Log.d("x00137044", "x00137044: "+ error.getMessage());
            }
        }) {
           @Override
           public Map<String, String> getHeaders() throws AuthFailureError {
               HashMap<String, String> headers = new HashMap<String, String>();
               headers.put("Content-Type","application/json; charset=utf-8");
               return headers;
           }
        };
        mQueue.add(request);
    }

    public JSONObject getParams(Anime a){
        JSONObject params = new JSONObject();
        try {
            params.put("name", a.getName());
            params.put("genre", a.getGenre());
            params.put("description", a.getDescription());
            params.put("year", a.getYear());
            params.put("episodes", a.getEpisode());
            params.put("seasons", a.getSeasons());
            params.put("yearly quarter", a.getYearly_quarter());

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return params;
    }


}
