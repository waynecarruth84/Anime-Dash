package com.example.animedash;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.like.LikeButton;
import com.like.OnAnimationEndListener;
import com.like.OnLikeListener;
import com.mikepenz.community_material_typeface_library.CommunityMaterial;
import com.mikepenz.iconics.IconicsDrawable;

import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;

import butterknife.OnClick;
import de.hdodenhof.circleimageview.CircleImageView;

public class MoreAnimeInfo  extends AppCompatActivity implements OnLikeListener, OnAnimationEndListener {

    Button shareBt;
    LikeButton thumbBt;

    public MoreAnimeInfo(){

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more_anime_info);
        shareBt = (Button) findViewById(R.id.share_button);
        shareBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                String shareBody = "Share this anime";
                intent.putExtra(Intent.EXTRA_TEXT, shareBody);
                startActivity(Intent.createChooser(intent, "Share to..."));
            }
        });

        thumbBt = (LikeButton) findViewById(R.id.thumb_button);
        thumbBt.setOnAnimationEndListener(this);
        thumbBt.setOnLikeListener(this);

        usingCustomIcons();

        Bundle extras = getIntent().getExtras();
        String name = extras.getString("NAME");
        String genre = extras.getString("GENRE");
        String description = extras.getString("DESCRIPTION");
        String year = extras.getString("YEAR");
        String episode = extras.getString("EPISODE");
        String seasons = extras.getString("SEASONS");
        String yearly_quarter = extras.getString("YEARLY QUARTER");


        CircleImageView thumbnail;
        TextView name_id, genre_id, description_id, year_id, episode_id, seasons_id, yearly_quarter_id;



       // thumbnail = findViewById(R.id.thumbnail);
        name_id = findViewById(R.id.name_id);
        genre_id = findViewById((R.id.genre_id));
        description_id = findViewById(R.id.description_id);
        year_id = findViewById(R.id.year_id);
        episode_id = findViewById(R.id.episodes_id);
        seasons_id = findViewById(R.id.seasons_id);
        yearly_quarter_id = findViewById(R.id.yearly_quarter_id);


       // Glide.with(this).asBitmap().load(pictureLink).into(thumbnail);
        name_id.append(name);
        genre_id.append(genre);
        description_id.append(description);
        year_id.append(year);
        episode_id.append(episode);
        seasons_id.append(seasons);
        yearly_quarter_id.append(yearly_quarter);

    }

    public void usingCustomIcons() {
        thumbBt.setUnlikeDrawable(new BitmapDrawable(getResources(), new IconicsDrawable(this, CommunityMaterial.Icon.cmd_emoticon).colorRes(android.R.color.darker_gray).sizeDp(25).toBitmap()));
        thumbBt.setLikeDrawable(new BitmapDrawable(getResources(), new IconicsDrawable(this, CommunityMaterial.Icon.cmd_emoticon).colorRes(android.R.color.holo_blue_bright).sizeDp(25).toBitmap()));

    }

    @Override
    public void liked(LikeButton likeButton) {
        Toast.makeText(this, "Liked!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void unLiked (LikeButton likeButton) {
        Toast.makeText(this, "Disliked!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onAnimationEnd(LikeButton likeButton) {
        Log.d("MoreAnimeInfo", "End for %s" + likeButton);
    }

    @OnClick(R.id.thumb_button)
    public void navigateToList() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}

