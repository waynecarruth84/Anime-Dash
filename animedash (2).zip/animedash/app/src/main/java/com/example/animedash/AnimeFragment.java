package com.example.animedash;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import androidx.fragment.app.Fragment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class AnimeFragment extends Fragment {

    private String URL = "https://anime-dashapi.azure-api.net/v1/api/Anime/";
    private RequestQueue mQueue;
    private Context context;
    private RecyclerViewAdapter mAdapter;

    private ArrayList<String> names = new ArrayList<String>();
    private ArrayList<Integer> ids = new ArrayList<Integer>();
    private ArrayList<String> genres = new ArrayList<String>();
    private ArrayList<String> descriptions = new ArrayList<String>();
    private ArrayList<Integer> years = new ArrayList<Integer>();
    private ArrayList<Integer> episode = new ArrayList<Integer>();
    private ArrayList<Integer> season = new ArrayList<Integer>();
    private ArrayList<String> yearly_quarters = new ArrayList<String>();


    public AnimeFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_anime, container, false);
        getAll(view);
        return view;
    }

    private void initRecycler(View view){
        RecyclerView recyclerView = view.findViewById(R.id.recyclerviewid);
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(ids, names, genres, descriptions, years, episode, season, yearly_quarters, getContext());
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        //recyclerView.setHasFixedSize(true);
    }

    public synchronized void getAll(View view) {
        mQueue = Volley.newRequestQueue(getContext());
        StringRequest request = new StringRequest(com.android.volley.Request.Method.GET, URL,
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Anime ani = null;
                        try {
                            JSONArray jsonArray = new JSONArray(response);
                            for (int i = 0; i < jsonArray.length(); i++) {

                                JSONObject anime = jsonArray.getJSONObject(i);
                                if(!anime.isNull("id")){

                               
                                
                            //    String name = ani.getName();
                                
                                int id = anime.getInt("id");
                                String name = anime.getString("name");
                                String genre = anime.getString("genre");
                                String description = anime.getString("description");
                                int year = anime.getInt("year");
                                int episodes = anime.getInt("episodes");
                                int seasons = anime.getInt("seasons");
                                String yearly_quarter = anime.getString("yearly_quarter");


                             //   ids.add(id);
                                names.add(name);
                                genres.add(genre);
                                descriptions.add(description);
                                years.add(year);
                                episode.add(episodes);
                                season.add(seasons);
                                yearly_quarters.add(yearly_quarter);
                                }
                                for(int count  = 0; count < yearly_quarters.size(); count++){
                                    System.out.println(yearly_quarters.get(count));
                                }
                            }
                            initRecycler(view);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("--", "Failed " + error.getMessage());

            }
        });
        mQueue.add(request);

    }

    /*List<Anime> animet;
    public List<Anime> callGetAll(){
        Log.d("GETAll", "Making GetAll request");

        try{
            StringRequest strObjRequest = new StringRequest(Request.Method.GET, URL,
                    new Response.Listener<String>()
                    {
                        public void onResponse(String response){
                            Type listType = new TypeToken<List<Anime>>(){}.getType();
                            List<Anime> newAnime = new Gson().fromJson(response, listType);

                            animet = newAnime;

                            Log.d("GETAll", "Getting all Anime in SQL" + animet.toString());
                        }
                    },
                    new Response.ErrorListener()
                    {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            animet = null;
                            Log.d("GETAll", "Error: " + error.toString());
                        }
                    });
        }catch(Exception e){
            Log.d("GETAll", "Error: " + e.toString());
        }
        return animet;
    }*/

}
