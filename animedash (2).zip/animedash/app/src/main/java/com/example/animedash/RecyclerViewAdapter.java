package com.example.animedash;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;


@SuppressWarnings("unchecked")
public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {
    private static final String TAG = "RecyclerViewAdapter";
    private ArrayList<String> names = new ArrayList<String>();
    private ArrayList<Integer> ids = new ArrayList<Integer>();
    private ArrayList<String> genres = new ArrayList<String>();
    private ArrayList<String> descriptions = new ArrayList<String>();
    private ArrayList<Integer> years = new ArrayList<Integer>();
    private ArrayList<Integer> episode = new ArrayList<Integer>();
    private ArrayList<Integer> season = new ArrayList<Integer>();
    private ArrayList<String> yearly_quarters = new ArrayList<String>();
    private Context mContext;
    private ArrayList<Anime> animeList;
    private ArrayList<Anime> animeFiltered;

    public RecyclerViewAdapter(ArrayList<Integer> ids, ArrayList<String> names, ArrayList<String> genres, ArrayList<String> descriptions, ArrayList<Integer> years, ArrayList<Integer> episode, ArrayList<Integer> season,
                               ArrayList<String> yearly_quarters, Context mContext) {

        this.names = names;
        this.genres = genres;
        this.descriptions = descriptions;
        this.years = years;
        this.episode = episode;
        this.mContext = mContext;
        this.ids = ids;
        this.season = season;
        this.yearly_quarters = yearly_quarters;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_item, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewAdapter.ViewHolder holder, int position) {
        holder.animeName.setText(names.get(position));
        holder.animeGenre.setText(genres.get(position));
        holder.animeDescription.setText(descriptions.get(position));
        holder.animeEpisodes.setText(episode.get(position).toString());
        holder.parentLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Context context = view.getContext();
                Intent intent = new Intent(context, MoreAnimeInfo.class);
                intent.putExtra("ANIMEID", ids.get(position).toString());
                intent.putExtra("NAME", names.get(position));
                intent.putExtra("GENRE", genres.get(position));
                intent.putExtra("DESCRIPTION", descriptions.get(position));
                intent.putExtra("YEAR", years.get(position).toString());
                intent.putExtra("EPISODES", episode.get(position).toString());
                intent.putExtra("SEASONS", season.get(position).toString());
                intent.putExtra("YEARLY_QUARTER", yearly_quarters.get(position));

                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return names.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView animeName, animeGenre, animeDescription, animeEpisodes;
        LinearLayout parentLayout;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            animeName = itemView.findViewById(R.id.anime_name);
            animeGenre = itemView.findViewById(R.id.anime_genre);
            animeDescription = itemView.findViewById(R.id.anime_description);
            animeEpisodes = itemView.findViewById(R.id.anime_episodes);
        }
    }

}

